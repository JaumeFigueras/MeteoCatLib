# MeteoCatLib
Library to access MeteoCat agency public API and keep a local copy of its information
