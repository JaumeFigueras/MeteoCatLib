# MeteoCatLib
Library to access MeteoCat agency public API and keep a local copy of its information

To build the library:

python3 -m build

to uninstall it:
pip3 uninstall gisfire_meteocat_lib

to install it:
pip3 install ./dist/gisfire_meteocat_lib-0.1.0.tar.gz

